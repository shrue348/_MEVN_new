
exports.devMode  = true;
exports.host     = 'http://localhost:3000';